/**
 * VonageVoiceModule
 * A JS wrapper around the native VonageVoice module.
 * Provides call management, login/logout, DTMF, and event handling.
 */
declare const VonageVoiceModule: {
    /**
     * Log in to Vonage with a token
     * @param token - JWT or access token
     */
    login: (token: string) => any;
    /**
     * Log out from Vonage
     */
    logout: () => any;
    /**
     * Initiate a call
     * @param to - recipient identifier (number or userId)
     * @param from - sender identifier
     */
    call: (to: string, from: string) => any;
    /**
     * Answer an incoming call
     * @param callId - ID of the call to answer
     */
    answer: (callId: string) => any;
    /**
     * Reject an incoming call
     * @param callId - ID of the call to reject
     */
    reject: (callId: string) => any;
    /**
     * Hang up an ongoing call
     * @param callId - ID of the call to hang up
     */
    hangup: (callId: string) => any;
    /**
     * Mute an ongoing call
     * @param callId - ID of the call to mute
     */
    mute: (callId: string) => any;
    /**
     * Unmute an ongoing call
     * @param callId - ID of the call to unmute
     */
    unmute: (callId: string) => any;
    /**
     * Get the status of a call
     * @param callId - ID of the call
     */
    getCallStatus: (callId: string) => any;
    /**
     * Enable or disable speakerphone
     * @param enabled - true to enable speaker, false to disable
     */
    setSpeaker: (enabled: boolean) => any;
    /**
     * Send a DTMF tone during a call
     * @param tone - The DTMF tone to send
     */
    sendDTMF: (tone: string) => any;
    /**
     * Add an event listener
     * @param eventName - Name of the event to listen to
     * @param handler - Callback function executed on event
     * @returns { remove: () => void } - Object with remove function to unsubscribe
     */
    addListener: (eventName: string, handler: (...args: any[]) => void) => {
        remove: () => void;
    };
    /**
     * Remove all listeners for a specific event
     * @param eventName - Name of the event
     */
    removeAllListeners: (eventName: string) => void;
};
export default VonageVoiceModule;
//# sourceMappingURL=VonageVoice.d.ts.map